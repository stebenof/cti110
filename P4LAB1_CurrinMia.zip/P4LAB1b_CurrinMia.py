# Mia Currin
# 4/30/25
# P4Lab1b
# Draw Initials

#Import turtle

import turtle 
win = turtle.Screen()  #playground for turtles
t = turtle.Turtle() #creates turtle

# Define size, color, and shape of pen
t.pensize(4)
t.shape("turtle")
t.speed(3)
t.color("green")


# Function for the letter M
t.penup()
t.goto(-100,0) #position first initial
t.pendown()
t.left(90)
t.forward(100)
t.right(135)
t.forward(70)
t.left(90)
t.forward(70)
t.right(135)
t.forward(100)

# Pick up pen, move, and put down for next letter
t.penup()
t.goto(0,0)
t.pendown()

# Function for the letter C

t.setheading(180)
t.circle(100, 180)

# End commands
t.hideturtle()
win.mainloop()  #window will wait to close when user closes window
