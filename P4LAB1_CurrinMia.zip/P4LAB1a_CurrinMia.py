# Mia Currin
# 4/30/25
# P4LAB1a
# Draw a square and triangle


# Set up turtle
import turtle          # allows use of turtle
win = turtle.Screen()  # create playground
t = turtle.Turtle()

# Draw square 
t.forward(50)          # Tell t to move forward by 50 units
t.left(90)             # Tell t to turn by 90 degrees
t.forward(50)
t.left(90)
t.forward(50)
t.left(90)
t.forward(50)

# Draw triangle
t.pensize(3)
t.pencolor("green")
t.shape("turtle")

# Triangle sides: 360 / 3 = 120 degrees
t.forward(100)          
t.left(120)            
t.forward(100)
t.left(120)
t.forward(100)

# End command
win.mainloop()

